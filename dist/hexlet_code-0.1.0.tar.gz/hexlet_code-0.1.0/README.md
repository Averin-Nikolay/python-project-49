<a href="https://codeclimate.com/github/Averin-Nikolay/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/d40d4517ce8114b089fc/maintainability" /></a>
